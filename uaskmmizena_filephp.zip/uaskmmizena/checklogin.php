<?php
require_once 'koneksi.php';
if($con){
    $nip_guru= $_POST['nip_guru'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE nip_guru='$nip_guru' AND password='$password'";
    $result = mysqli_query($con, $query);
    $response = array();

    $row = mysqli_num_rows($result);


    if ($row > 0){
        array_push($response, array(
            'status' => 'OK'
        ));
    }else{
        array_push($response, array(
            'status' => 'FAILED'
        ));
    }
}else{
    array_push($response, array(
        'status' => 'FAILED'
    ));
}

echo json_encode(array("server_response" => $response));
mysqli_connect($con);
?>