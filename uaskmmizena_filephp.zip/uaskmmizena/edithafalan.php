<?php  
	$con = mysqli_connect("localhost","root","","uaskmmizena");

	if (mysqli_connect_errno()) {
		echo "koneksi database gagal: ".mysqli_connect_error();
	}

	$id_hafalan = $_POST['id_hafalan'];
	$surat = $_POST['surat'];
	$ayat = $_POST['ayat'];
	$tanggal = $_POST['tanggal'];

	//query untuk insert data ke MySQL 

	$query = "update hafalan set surat='$surat', ayat='$ayat', tanggal='$tanggal' where id_hafalan='$id_hafalan'";
	$result = mysqli_query($con,$query);

	// pesan yang akan tertampil dalam aplikasi android
	 if ($result) {
	 	echo "data sudah terupdate";
	 }
?>