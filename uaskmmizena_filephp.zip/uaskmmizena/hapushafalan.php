<?php  
	$con=mysqli_connect("localhost","root","","uaskmmizena");

	if (mysqli_connect_errno()) {
		echo "koneksi database gagal: ".mysqli_connect_error();
	}

	$id_hafalan = $_POST['id_hafalan'];


	$query = "delete from hafalan where id_hafalan='$id_hafalan'";
	$tersimpan = mysqli_query($con,$query);
?>