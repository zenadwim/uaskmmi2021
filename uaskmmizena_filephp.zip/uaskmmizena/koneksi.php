<?php
$con = mysqli_connect("localhost", "root", "", "uaskmmizena");
?>