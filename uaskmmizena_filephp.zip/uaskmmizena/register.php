<?php
require_once 'koneksi.php';
if($con){
    $nip_guru = $_POST['nip_guru'];
    $password = $_POST['password'];

    $query = "INSERT INTO users (nip_guru, password) VALUES ('$nip_guru', '$password')";


    if ($nip_guru != "" && $password != ""){
        $result = mysqli_query($con, $query);
        $response = array();

        if($result){
            array_push($response, array(
                'status' => 'OK'
            ));
        }else{
            array_push($response, array(
                'status' => 'FAILED'
            ));
        }
    }else{
        array_push($response, array(
            'status' => 'FAILED'
        ));
    }
}else{
    array_push($response, array(
        'status' => 'FAILED'
    ));
}

echo json_encode(array("server_response" => $response));
mysqli_connect($con);
?>