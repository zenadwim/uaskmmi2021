<?php
    $con = mysqli_connect("localhost","root","","uaskmmizena");

	if (mysqli_connect_errno()){
		echo "koneksi database gagal:".mysqli_connect_error();
	}

	$surat = $_POST['surat'];
	$ayat = $_POST['ayat'];
	$nisn = $_POST['nisn'];
	$tanggal = $_POST['tanggal'];

	// query untuk insert data ke MYSQL
	$query = "insert into hafalan values ('id_hafalan', '$surat', '$ayat' ,'$nisn' ,'$tanggal')";
	$tersimpan = mysqli_query($con, $query);

	// pesan yang akan tertampil dalam aplikasi android
	if($tersimpan)
		echo "hafalan sudah tersimpan";

?>