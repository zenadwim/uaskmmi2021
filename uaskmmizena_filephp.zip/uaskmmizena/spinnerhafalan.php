<?php  
$con=mysqli_connect("localhost","root","","uaskmmizena");
$sql = "SELECT * FROM surat";
if (!$con->query($sql)) {
	echo "Database Errorss";
} else {
	$result = $con->query($sql);
	if ($result->num_rows > 0) {
		$return_arr['surat'] = array();
		while($row = $result->fetch_array()){
			array_push($return_arr['surat'], array(
				'id_surat'=>$row['id_surat'],
				'nama_surat'=>$row['nama_surat']
			));
		}
		echo json_encode($return_arr);
	}
}

?>