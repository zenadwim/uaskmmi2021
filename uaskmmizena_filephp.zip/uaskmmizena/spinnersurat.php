<?php
$con=mysqli_connect("localhost","root","","uaskmmizena");
$id_kelas= $_POST['id_kelas'];
$sql = "SELECT * FROM surat WHERE id_kelas='$id_kelas'";
if(!$con->query($sql)){
    echo "error konek database"
}else{
    $result = con->query($sql);
    if($result->num_rows>0){
        $return_arr[]
    }
}

?>