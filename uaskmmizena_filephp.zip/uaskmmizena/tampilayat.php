<?php
	$con=mysqli_connect("localhost","root","","uaskmmizena");
	
	$surat = $_POST['surat'];

	$query = "SELECT ayat FROM hafalan where nama_surat='$surat'";
	$result = mysqli_query($con,$query);
	$row = mysqli_fetch_array($result, MYSQLI_NUM);
	$data = $row[0];
	if ($data){
		echo $data;
	}

?>