<?php
$con=mysqli_connect("localhost","root","","uaskmmizena");
if (isset($_GET['nip_guru'])) {
    $sql = "SELECT * FROM kelas WHERE nip_guru='".$_GET['nip_guru']."'";
    if (!$con->query($sql)) {
        echo "Error";
    } else {
        $result = $con->query($sql);
        $json = array();
        while($row = mysqli_fetch_assoc($result)){
            $json[] = $row;
        }
        echo json_encode($json);
    }
}

?>