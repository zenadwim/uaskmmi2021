<?php
$con=mysqli_connect("localhost","root","","uaskmmizena");
if (isset($_GET['id_kelas'])) {
    $sql = "SELECT * FROM siswa WHERE id_kelas='".$_GET['id_kelas']."'";
    if (!$con->query($sql)) {
        echo "Error";
    } else {
        $result = $con->query($sql);
        $json = array();
        while($row = mysqli_fetch_assoc($result)){
            $json[] = $row;
        }
        echo json_encode($json);
    }
}

?>